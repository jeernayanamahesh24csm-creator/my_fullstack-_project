/* ─────────────────────────────────────────────────────────────────────────────
   Energy Waste Detective – app.js  (Frontend JavaScript)
   ───────────────────────────────────────────────────────────────────────────── */

const API = '';   // Same-origin — express serves this file

// ── Chart instances (kept so we can destroy/redraw) ──────────────────────────
let timelineChart = null;
let weeklyChart   = null;
let monthlyChart  = null;

// ── State ────────────────────────────────────────────────────────────────────
let currentFilter = 'all';
let allAnnotated  = [];

// ─────────────────────────────────────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────────────────────────────────────
function showToast(msg, type = 'info') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast toast-${type} show`;
  clearTimeout(el._timer);
  el._timer = setTimeout(() => { el.classList.remove('show'); }, 3400);
}

// ─────────────────────────────────────────────────────────────────────────────
// API HELPERS
// ─────────────────────────────────────────────────────────────────────────────
async function apiFetch(endpoint, options = {}) {
  const res = await fetch(API + endpoint, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}

// ─────────────────────────────────────────────────────────────────────────────
// FETCH & RENDER – central refresh function
// ─────────────────────────────────────────────────────────────────────────────
async function refresh() {
  try {
    const data = await apiFetch('/api/analysis');
    allAnnotated = data.annotated || [];
    renderKPIs(data);
    renderTimeline(data.annotated || []);
    renderWeekly(data.weekly || []);
    renderMonthly(data.monthly || []);
    renderAnomalies(data.annotated || []);
    renderSuggestions(data.suggestions || []);
    renderBillBreakdown(data.totalKwh || 0, data.estimatedMonthlyBill || 0);
    renderTable(data.annotated || []);
  } catch (e) {
    showToast('Failed to load data: ' + e.message, 'error');
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// KPIs
// ─────────────────────────────────────────────────────────────────────────────
function renderKPIs(data) {
  document.getElementById('kpiReadings').textContent  = data.totalReadings || 0;
  document.getElementById('kpiTotal').textContent     = `${(data.totalKwh || 0).toFixed(2)} kWh`;
  document.getElementById('kpiAvg').textContent       = `${(data.mean || 0).toFixed(2)} kWh`;
  document.getElementById('kpiAnomalies').textContent = `${data.anomalyCount || 0} (${data.anomalyRate || 0}%)`;
  document.getElementById('kpiBill').textContent      = `₹${(data.estimatedMonthlyBill || 0).toFixed(2)}`;
  document.getElementById('kpiPeak').textContent      = `${(data.max || 0).toFixed(3)} kWh`;
}

// ─────────────────────────────────────────────────────────────────────────────
// TIMELINE CHART
// ─────────────────────────────────────────────────────────────────────────────
function renderTimeline(annotated) {
  const ctx = document.getElementById('timelineChart').getContext('2d');
  if (timelineChart) { timelineChart.destroy(); timelineChart = null; }

  if (!annotated.length) return;

  const labels  = annotated.map(r => formatDT(r.timestamp));
  const values  = annotated.map(r => r.kwh);
  const meanVal = annotated[0]?.mean ?? 0;

  const pointBg = annotated.map(r =>
    r.severity === 'high'   ? '#ef4444' :
    r.severity === 'medium' ? '#f59e0b' : '#4f8ef7'
  );
  const pointRadius = annotated.map(r => r.anomaly ? 6 : 4);

  timelineChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'kWh',
          data: values,
          borderColor: '#4f8ef7',
          backgroundColor: 'rgba(79,142,247,.08)',
          fill: true,
          tension: 0.35,
          pointBackgroundColor: pointBg,
          pointRadius,
          pointHoverRadius: 8,
          borderWidth: 2
        },
        {
          label: 'Mean',
          data: Array(values.length).fill(meanVal),
          borderColor: '#fbbf24',
          borderDash: [6, 4],
          borderWidth: 1.5,
          pointRadius: 0,
          fill: false
        }
      ]
    },
    options: chartOptions('kWh Consumption', true)
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// WEEKLY CHART
// ─────────────────────────────────────────────────────────────────────────────
function renderWeekly(weekly) {
  const ctx = document.getElementById('weeklyChart').getContext('2d');
  if (weeklyChart) { weeklyChart.destroy(); weeklyChart = null; }
  if (!weekly.length) return;

  weeklyChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: weekly.map(w => `Wk ${w.week}`),
      datasets: [
        {
          label: 'Total kWh',
          data: weekly.map(w => w.totalKwh.toFixed(2)),
          backgroundColor: weekly.map(w =>
            w.anomalies > 2 ? 'rgba(239,68,68,.7)'
            : w.anomalies > 0 ? 'rgba(245,158,11,.7)'
            : 'rgba(79,142,247,.7)'
          ),
          borderRadius: 6
        }
      ]
    },
    options: chartOptions('kWh per Week', false)
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// MONTHLY CHART
// ─────────────────────────────────────────────────────────────────────────────
function renderMonthly(monthly) {
  const ctx = document.getElementById('monthlyChart').getContext('2d');
  if (monthlyChart) { monthlyChart.destroy(); monthlyChart = null; }
  if (!monthly.length) return;

  monthlyChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: monthly.map(m => m.month),
      datasets: [
        {
          label: 'kWh',
          data: monthly.map(m => m.totalKwh.toFixed(2)),
          backgroundColor: 'rgba(79,142,247,.75)',
          borderRadius: 6,
          yAxisID: 'y'
        },
        {
          label: 'Est. Bill (₹)',
          data: monthly.map(m => m.estimatedBill),
          type: 'line',
          borderColor: '#a78bfa',
          backgroundColor: 'rgba(167,139,250,.08)',
          tension: 0.3,
          fill: true,
          pointRadius: 5,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      ...chartOptions('Monthly Overview', false),
      scales: {
        x:  darkScale(),
        y:  { ...darkScale(), position: 'left',  title: { display: true, text: 'kWh', color: '#8896b3', font:{size:10} } },
        y1: { ...darkScale(), position: 'right', grid: { drawOnChartArea: false },
              title: { display: true, text: '₹', color: '#8896b3', font:{size:10} } }
      }
    }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// CHART CONFIG HELPERS
// ─────────────────────────────────────────────────────────────────────────────
function darkScale() {
  return {
    ticks: { color: '#8896b3', font: { size: 10 } },
    grid:  { color: 'rgba(46,50,73,.7)' }
  };
}

function chartOptions(title, showLegend) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend:  { display: showLegend, labels: { color: '#8896b3', boxWidth: 12, font:{size:11} } },
      tooltip: {
        backgroundColor: '#1a1d27',
        borderColor: '#2e3249',
        borderWidth: 1,
        titleColor: '#e2e8f0',
        bodyColor: '#8896b3',
        callbacks: {
          afterLabel: (ctx) => {
            const item = allAnnotated[ctx.dataIndex];
            if (!item || !item.anomaly) return '';
            return '⚠ ' + item.reasons.map(r => r.label).join(', ');
          }
        }
      }
    },
    scales: { x: darkScale(), y: darkScale() }
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ANOMALY LIST
// ─────────────────────────────────────────────────────────────────────────────
function renderAnomalies(annotated) {
  const anomalies = annotated.filter(r => r.anomaly);
  document.getElementById('anomalyBadge').textContent = anomalies.length;

  const container = document.getElementById('anomalyList');
  const filtered  = currentFilter === 'all' ? anomalies
    : anomalies.filter(r => r.severity === currentFilter);

  if (!filtered.length) {
    container.innerHTML = `<p class="empty-state">${
      anomalies.length ? 'No anomalies match the current filter.' : 'No anomalies detected. Great job! 🎉'
    }</p>`;
    return;
  }

  container.innerHTML = filtered.map(r => `
    <div class="anomaly-item severity-${r.severity}">
      <div class="anomaly-ts">${formatDT(r.timestamp)}</div>
      <div class="anomaly-kwh">${r.kwh} kWh</div>
      ${r.label ? `<div style="font-size:.75rem;color:#8896b3">${escHtml(r.label)}</div>` : ''}
      <div class="anomaly-rules">
        ${r.reasons.map(rs => `
          <span class="rule-tag rule-tag-${r.severity}" title="${escHtml(rs.detail)}">
            ${rs.rule}: ${rs.label}
          </span>`).join('')}
      </div>
    </div>
  `).join('');
}

// ─────────────────────────────────────────────────────────────────────────────
// SUGGESTIONS
// ─────────────────────────────────────────────────────────────────────────────
function renderSuggestions(suggestions) {
  const el = document.getElementById('suggestionsList');
  if (!suggestions.length) {
    el.innerHTML = '<p class="empty-state">No suggestions yet.</p>';
    return;
  }
  el.innerHTML = suggestions.map(s =>
    `<div class="suggestion-item">${escHtml(s)}</div>`
  ).join('');
}

// ─────────────────────────────────────────────────────────────────────────────
// BILL BREAKDOWN
// ─────────────────────────────────────────────────────────────────────────────
function renderBillBreakdown(totalKwh, estimatedBill) {
  const el = document.getElementById('billBreakdown');
  if (!totalKwh) {
    el.innerHTML = '<p class="empty-state">Add readings to see billing breakdown.</p>';
    return;
  }

  const slabs = [
    { range: '0 – 100 kWh',   rate: 3.50, limit: 100 },
    { range: '101 – 300 kWh', rate: 5.00, limit: 200 },
    { range: '301 – 500 kWh', rate: 6.50, limit: 200 },
    { range: '500+ kWh',      rate: 8.00, limit: Infinity }
  ];

  let remaining = totalKwh;
  let cards = '';

  slabs.forEach(slab => {
    if (remaining <= 0) return;
    const units = Math.min(remaining, slab.limit);
    const cost  = units * slab.rate;
    remaining  -= units;
    cards += `
      <div class="bill-slab">
        <div class="slab-range">${slab.range}</div>
        <div class="slab-rate">₹${slab.rate.toFixed(2)}/kWh</div>
        <div class="slab-units">${units.toFixed(2)} kWh used</div>
        <div class="slab-cost">₹${cost.toFixed(2)}</div>
      </div>`;
  });

  cards += `
    <div class="bill-total">
      <div>
        <div class="bill-total-label">💰 Estimated Monthly Bill</div>
        <div style="font-size:.75rem;color:#8896b3">Includes ₹50 fixed charge</div>
      </div>
      <div class="bill-total-value">₹${estimatedBill.toFixed(2)}</div>
    </div>`;

  el.innerHTML = cards;
}

// ─────────────────────────────────────────────────────────────────────────────
// READINGS TABLE
// ─────────────────────────────────────────────────────────────────────────────
function renderTable(annotated, filter = '') {
  const tbody = document.getElementById('readingsTbody');
  const q = filter.trim().toLowerCase();

  const rows = annotated.filter(r =>
    !q
    || r.kwh.toString().includes(q)
    || (r.label || '').toLowerCase().includes(q)
    || r.timestamp.includes(q)
    || (r.anomaly && 'anomaly'.includes(q))
  );

  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="empty-cell">No readings match your filter.</td></tr>`;
    return;
  }

  tbody.innerHTML = rows.map(r => {
    const pillClass = r.severity === 'high' ? 'pill-high'
      : r.severity === 'medium' ? 'pill-anomaly' : 'pill-normal';
    const pillLabel = r.anomaly
      ? (r.severity === 'high' ? '🔴 High Anomaly' : '🟡 Anomaly')
      : '🟢 Normal';

    return `
      <tr class="${r.anomaly ? 'row-anomaly' : ''}">
        <td>${formatDT(r.timestamp)}</td>
        <td><strong>${r.kwh}</strong></td>
        <td>${escHtml(r.label || '—')}</td>
        <td><span class="source-tag">${escHtml(r.source || 'manual')}</span></td>
        <td><span class="status-pill ${pillClass}">${pillLabel}</span></td>
        <td>
          <div class="reason-list">
            ${(r.reasons || []).map(rs => `
              <span class="rule-tag rule-tag-${r.severity}" title="${escHtml(rs.detail)}">
                ${rs.rule}
              </span>`).join('') || '—'}
          </div>
        </td>
        <td>
          <button class="btn-icon" onclick="deleteReading('${r.id}')" title="Delete reading">🗑</button>
        </td>
      </tr>`;
  }).join('');
}

// ─────────────────────────────────────────────────────────────────────────────
// DELETE READING
// ─────────────────────────────────────────────────────────────────────────────
async function deleteReading(id) {
  try {
    await apiFetch(`/api/readings/${id}`, { method: 'DELETE' });
    showToast('Reading deleted.', 'info');
    await refresh();
  } catch (e) {
    showToast('Delete failed: ' + e.message, 'error');
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILS
// ─────────────────────────────────────────────────────────────────────────────
function formatDT(iso) {
  const d = new Date(iso);
  return d.toLocaleString('en-IN', {
    month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true
  });
}

function escHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

// ─────────────────────────────────────────────────────────────────────────────
// EVENT LISTENERS
// ─────────────────────────────────────────────────────────────────────────────

// ── Add Reading Form ──
document.getElementById('addForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const kwh  = parseFloat(document.getElementById('inputKwh').value);
  const time = document.getElementById('inputTime').value;
  const label= document.getElementById('inputLabel').value.trim();

  if (isNaN(kwh) || kwh < 0) {
    showToast('Please enter a valid kWh value.', 'error');
    return;
  }

  try {
    await apiFetch('/api/readings', {
      method: 'POST',
      body: JSON.stringify({ kwh, timestamp: time || undefined, label })
    });
    e.target.reset();
    showToast(`✅ Reading of ${kwh} kWh added!`, 'success');
    await refresh();
  } catch (err) {
    showToast('Error: ' + err.message, 'error');
  }
});

// ── Seed Demo Data ──
document.getElementById('btnSeed').addEventListener('click', async () => {
  try {
    const res = await apiFetch('/api/seed', { method: 'POST' });
    showToast(`🌱 Loaded ${res.seeded} demo readings!`, 'success');
    await refresh();
  } catch (e) {
    showToast('Seed failed: ' + e.message, 'error');
  }
});

// ── Export ──
document.getElementById('btnExport').addEventListener('click', () => {
  window.location.href = '/api/export';
  showToast('📤 Downloading readings…', 'info');
});

// ── Import ──
document.getElementById('fileImport').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const json = JSON.parse(text);
    const res  = await apiFetch('/api/import', {
      method: 'POST',
      body: JSON.stringify(json)
    });
    showToast(`📥 Imported ${res.imported} readings!`, 'success');
    await refresh();
  } catch (err) {
    showToast('Import failed: ' + err.message, 'error');
  }
  e.target.value = '';
});

// ── Clear All ──
document.getElementById('btnClearAll').addEventListener('click', async () => {
  if (!confirm('Delete ALL readings? This cannot be undone.')) return;
  try {
    await apiFetch('/api/readings', { method: 'DELETE' });
    showToast('All readings cleared.', 'info');
    await refresh();
  } catch (e) {
    showToast('Error: ' + e.message, 'error');
  }
});

// ── Anomaly Filter Buttons ──
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderAnomalies(allAnnotated);
  });
});

// ── Table Search ──
document.getElementById('tableSearch').addEventListener('input', (e) => {
  renderTable(allAnnotated, e.target.value);
});

// ─────────────────────────────────────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────────────────────────────────────
(async () => {
  // Pre-fill datetime to now
  const now = new Date();
  now.setSeconds(0, 0);
  document.getElementById('inputTime').value = now.toISOString().slice(0, 16);

  await refresh();
})();
